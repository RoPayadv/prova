from flask import Flask, render_template, request, redirect, flash
import os
import requests

app = Flask(__name__)
app.secret_key = 'supersegreto'

ACCESS_TOKEN = os.environ.get('ACCESS_TOKEN')
PAGE_ID = os.environ.get('PAGE_ID')
IG_USER_ID = os.environ.get('IG_USER_ID')


def publish_to_facebook(caption, image_url):
    url = f"https://graph.facebook.com/v19.0/{PAGE_ID}/photos"
    payload = {'url': image_url, 'caption': caption, 'access_token': ACCESS_TOKEN}
    res = requests.post(url, data=payload)
    return res.json()


def publish_to_instagram(caption, image_url):
    container_url = f"https://graph.facebook.com/v19.0/{IG_USER_ID}/media"
    payload = {'image_url': image_url, 'caption': caption, 'access_token': ACCESS_TOKEN}
    res = requests.post(container_url, data=payload).json()
    creation_id = res.get('id')
    if not creation_id:
        return {"error": "Errore nella creazione del container Instagram"}
    publish_url = f"https://graph.facebook.com/v19.0/{IG_USER_ID}/media_publish"
    publish_payload = {'creation_id': creation_id, 'access_token': ACCESS_TOKEN}
    res = requests.post(publish_url, data=publish_payload)
    return res.json()


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        caption = request.form.get("caption")
        image_url = request.form.get("image_url")
        fb_result = publish_to_facebook(caption, image_url)
        ig_result = publish_to_instagram(caption, image_url)
        flash(f"✅ Facebook: {fb_result}", "success")
        flash(f"✅ Instagram: {ig_result}", "success")
        return redirect("/")
    return render_template("index.html")


if __name__ == "__main__":
    app.run()