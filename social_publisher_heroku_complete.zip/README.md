# Social Publisher – Facebook & Instagram via Meta API

Questa è una semplice applicazione **Flask** che consente di pubblicare post (immagine + didascalia) su **Facebook** e **Instagram** utilizzando la **Meta Graph API**.

## 🚀 Funzionalità
- Interfaccia web per inserire testo e URL immagine
- Pubblicazione automatica su:
  - Facebook Page
  - Instagram Business Account collegato
- Pronto per il deploy su Heroku

## 🗂️ Struttura
```
.
├── app.py
├── requirements.txt
├── Procfile
├── templates/
│   └── index.html
├── README.md
```

## 🛠️ Configurazione ambiente
Imposta le seguenti variabili d'ambiente su Heroku:

- `ACCESS_TOKEN` → il token di accesso Meta valido
- `PAGE_ID` → l'ID della Pagina Facebook
- `IG_USER_ID` → l'ID dell'account Instagram Business

## 🧪 Esecuzione locale
```bash
pip install -r requirements.txt
python app.py
```

## ☁️ Deploy su Heroku
```bash
heroku create nome-tua-app
heroku buildpacks:set heroku/python
git push heroku master
heroku config:set ACCESS_TOKEN=... PAGE_ID=... IG_USER_ID=...
heroku open
```

## 📸 Screenshot
![screenshot](https://via.placeholder.com/600x300?text=Social+Publisher+Demo)

---

Creato per semplificare la pubblicazione cross-platform via API ✅